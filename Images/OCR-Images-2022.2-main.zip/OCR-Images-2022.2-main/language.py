import cv2

LANG = 'por'