import cv2

custom_config_num = r'--oem 3 --psm 6 outputbase digits'
custom_config_wl = r'-c tessedit_char_whitelist=procesamentdig --psm 6'